# LBoL_Komachi
A mod for Lost Branch of Legends that adds Komachi as a playable character.
